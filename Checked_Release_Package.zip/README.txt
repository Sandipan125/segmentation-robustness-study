Controlled phantom study: portable release

Install: python -m pip install -r code/requirements.txt
From the package root, enter results/ before running scripts:
cd results
python ../code/run_main.py
python ../code/run_rep.py
python ../code/summ_rep.py
python ../code/run_cnn.py 1 30
python ../code/run_cnn.py 2 30
python ../code/run_cnn.py 3 30
python ../code/summ_cnn.py
python ../code/run_timing.py

These commands rerun experiments and overwrite matching results; use a working copy. They were not all rerun during this packaging pass. Supplied CNN weights are absent; CNN commands retrain from seeds. Runtime depends on CPU and BLAS configuration.
Compile latex/Final_Paper.tex twice with pdfLaTeX.

Open scientific work: medical-image validation, CNN threshold controls, and class-conditional score reporting. No new experimental results are claimed by this packaging revision. Attach this ZIP as supplementary material before retaining that availability statement in the paper.
