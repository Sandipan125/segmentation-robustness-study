import sys;sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent))
from cnn import *
s=int(sys.argv[1]);EP=int(sys.argv[2]) if len(sys.argv)>2 else 30
tr=[phantomA(i,2026+90_000_000+1_000_000*s) for i in range(300)]
net=FCN(seed=s);train(net,tr,EP,s)
dev=[phantomA(i,2026) for i in range(40)];cal=[phantomA(i,2026) for i in range(40,80)]
grid=np.linspace(-3,3,61)
Zd=[(net.forward(x),y) for x,y in dev]
ds=[np.mean([R.dice(z>=t,y) for z,y in Zd]) for t in grid];th=float(grid[int(np.argmax(ds))])
Zc=np.stack([net.forward(x)-th for x,y in cal]);Lc=np.stack([y for x,y in cal])
f=minimize_scalar(lambda lt:nll(Zc/np.exp(lt),Lc),bounds=(np.log(.05),np.log(10)),method='bounded');tt=float(np.exp(f.x))
pl=minimize(lambda p:nll(p[0]*Zc+p[1],Lc),[1.,0.],method='L-BFGS-B')
cfg={'threshold':th,'temperature':tt,'platt_a':float(pl.x[0]),'platt_b':float(pl.x[1])};print(cfg)
rows=[]
for i in range(80,160):
    x,y=phantomA(i)
    for cond in R.CONDITIONS:
        z=net.forward(shiftS(x,cond,i))-th;pred=z>=0
        pr=expit(z);pt=expit(z/tt);pp=expit(cfg['platt_a']*z+cfg['platt_b'])
        rows.append({'seed':s,'case':i,'condition':cond,'dice':R.dice(pred,y),'hd95':R.hd95(pred,y),
          'brier_raw':float(2*np.mean((pr-y)**2)),'brier_temp':float(2*np.mean((pt-y)**2)),'brier_platt':float(2*np.mean((pp-y)**2)),
          'nll_raw':nll(z,y),'nll_temp':nll(z/tt,y),'nll_platt':nll(cfg['platt_a']*z+cfg['platt_b'],y)})
d=pd.DataFrame(rows);d.to_csv(f'cnn_seed{s}.csv',index=False)
pd.json_normalize([cfg]).to_csv(f'cnn_cfg{s}.csv',index=False)
print(d.groupby('condition').mean(numeric_only=True)[['dice','hd95','brier_raw','brier_temp','brier_platt','nll_raw','nll_temp','nll_platt']].round(3).to_string())
