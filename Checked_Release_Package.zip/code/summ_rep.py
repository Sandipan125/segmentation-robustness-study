import pandas as pd, numpy as np
pd.set_option('display.width',250)
d=pd.read_csv('ext_rep_case.csv')
# per-replicate means
g=d.groupby(['family','fit','rep','model','condition']).mean(numeric_only=True).reset_index()
cols=['dice','brier_raw','brier_temp','brier_platt','nll_raw','nll_temp','nll_platt']
w=g.pivot_table(index=['family','fit','rep','condition'],columns='model',values=cols)
res=[]
for (fam,fit,cond),x in w.groupby(level=[0,1,3]):
    r={'family':fam,'fit':fit,'condition':cond}
    for m,k in [('Threshold','T'),('Smoothed threshold','ST')]:
        r[f'dice_{k}']=x[('dice',m)].mean();r[f'dice_{k}_sd']=x[('dice',m)].std()
        r[f'tempWorse_{k}']=(x[('brier_temp',m)]>x[('brier_raw',m)]).mean()
        r[f'plattWorse_{k}']=(x[('brier_platt',m)]>x[('brier_raw',m)]).mean()
        r[f'brier_raw_{k}']=x[('brier_raw',m)].mean();r[f'brier_temp_{k}']=x[('brier_temp',m)].mean();r[f'brier_platt_{k}']=x[('brier_platt',m)].mean()
        r[f'nll_raw_{k}']=x[('nll_raw',m)].mean();r[f'nll_temp_{k}']=x[('nll_temp',m)].mean();r[f'nll_platt_{k}']=x[('nll_platt',m)].mean()
    diff=x[('dice','Smoothed threshold')]-x[('dice','Threshold')]
    r['diff_mean']=diff.mean();r['diff_sd']=diff.std();r['diff_min']=diff.min();r['diff_max']=diff.max();r['frac_ST_better']=(diff>0).mean()
    res.append(r)
res=pd.DataFrame(res);res.to_csv('ext_rep_summary.csv',index=False)
print(res[['family','fit','condition','dice_T','dice_ST','diff_mean','diff_sd','diff_min','diff_max','frac_ST_better']].round(3).to_string())
print(res[['family','fit','condition','brier_raw_T','brier_temp_T','brier_platt_T','tempWorse_T','plattWorse_T','brier_raw_ST','brier_temp_ST','brier_platt_ST','tempWorse_ST','plattWorse_ST']].round(3).to_string())
print(res[['family','fit','condition','nll_raw_T','nll_temp_T','nll_platt_T','nll_raw_ST','nll_temp_ST','nll_platt_ST']].round(3).to_string())
th=d.drop_duplicates(['family','rep','fit','model'])[['family','fit','model','theta','temp']]
print(th.groupby(['family','fit','model']).agg(['mean','std','min','max']).round(3))
