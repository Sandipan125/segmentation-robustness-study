import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=str(__import__('pathlib').Path(__file__).resolve().parents[1]/'results')+'/'
sm=pd.read_csv(P+'synthetic_summary.csv'); df=pd.read_csv(P+'synthetic_case_metrics.csv')
pc=pd.read_csv(P+'synthetic_paired_comparisons.csv'); print(pc.round(3).to_string())
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Liberation Serif','DejaVu Serif'],'font.size':7,
 'axes.linewidth':.6,'axes.spines.top':False,'axes.spines.right':False,'xtick.major.width':.6,'ytick.major.width':.6,
 'mathtext.fontset':'stix'})
models=['Threshold','Smoothed threshold']; cols=['#1f4e9c','#b8412a']; mk=['o','s']
fams=['noise','blur','contrast','resolution']
fig,axs=plt.subplots(2,4,figsize=(5.6,2.45),sharey='row')
for r,(metric,yl) in enumerate([('dice','Dice coefficient'),('brier_scaled','Calibrated Brier score')]):
    for ax,f in zip(axs[r],fams):
        for m,c,k in zip(models,cols,mk):
            d=sm[sm.model==m].set_index('condition').loc[['clean']+[f'{f}_{i}' for i in (1,2,3)]]
            ax.fill_between(range(4),d[metric+'_ci_low'],d[metric+'_ci_high'],color=c,alpha=.18,lw=0)
            ax.plot(range(4),d[metric],marker=k,ms=3,lw=1,color=c,label='T' if m==models[0] else 'ST')
        ax.set_xticks(range(4)); ax.grid(alpha=.25,lw=.4)
        if r==0: ax.set_title(f.capitalize(),fontsize=8)
        if r==1: ax.set_xlabel('Severity level')
    axs[r][0].set_ylabel(yl)
axs[0][3].legend(fontsize=6.5,frameon=False,loc='lower left')
fig.tight_layout(pad=.4); fig.savefig('curves.pdf'); plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(3.45,1.9))
for ax,c in zip(axs,['clean','noise_3']):
    d=df[df.condition==c].pivot(index='case',columns='model',values='dice')
    ax.scatter(d[models[0]],d[models[1]],s=5,alpha=.7,color=cols[0],lw=0)
    ax.plot([0,1],[0,1],'--',color='gray',lw=.7); ax.set(xlim=(0,1),ylim=(0,1),title=c.replace('_',' '),xlabel='T Dice')
    ax.set_title(c.replace('_',' '),fontsize=7); ax.grid(alpha=.25,lw=.4); ax.set_aspect('equal')
axs[0].set_ylabel('ST Dice'); fig.tight_layout(pad=.3); fig.savefig('scatter.pdf'); plt.close(fig)
# table check
t=sm.set_index(['model','condition'])
for m in models:
    for c in ['clean','noise_3','blur_3','contrast_3','resolution_3']:
        r=t.loc[(m,c)]; print(m[:2],c,*[round(r[k],3) for k in ['dice','hd95_pixels','ece_raw','ece_scaled','brier_raw','brier_scaled']])
