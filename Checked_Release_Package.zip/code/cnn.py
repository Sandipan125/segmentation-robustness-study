import sys,time;sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent))
from extlib import *
OFF=lambda d:[(i*d,j*d) for i in(-1,0,1) for j in(-1,0,1)]
class FCN:
    """Small fully convolutional net: 3x3 conv (d=1,2,4) x3 with ReLU, then 1x1 conv to a logit (RF 15x15). NumPy, manual backprop."""
    def __init__(s,C=12,seed=0):
        r=np.random.default_rng(seed);s.dil=[1,2,4];cin=[1,C,C]
        s.W=[r.normal(0,np.sqrt(2/(9*c)),(9*c,C)) for c in cin]+[r.normal(0,np.sqrt(1/C),(C,1))]
        s.b=[np.zeros(C) for _ in range(3)]+[np.zeros(1)]
        s.m=[np.zeros_like(p) for p in s.W+s.b];s.v=[np.zeros_like(p) for p in s.W+s.b];s.t=0
    @staticmethod
    def cols(a,d):
        H,W,Cn=a.shape;p=np.pad(a,((d,d),(d,d),(0,0)))
        return np.concatenate([p[d+i:d+i+H,d+j:d+j+W] for i,j in OFF(d)],axis=2).reshape(H*W,9*Cn)
    @staticmethod
    def uncols(dc,shape,d):
        H,W,Cn=shape;dc=dc.reshape(H,W,9,Cn);dp=np.zeros((H+2*d,W+2*d,Cn))
        for k,(i,j) in enumerate(OFF(d)):dp[d+i:d+i+H,d+j:d+j+W]+=dc[:,:,k]
        return dp[d:d+H,d:d+W]
    def forward(s,x,keep=False):
        a=((x-.35)/.2)[:,:,None];H,W=x.shape;cache=[]
        for k in range(3):
            c=s.cols(a,s.dil[k]);z=c@s.W[k]+s.b[k];o=np.maximum(z,0);cache.append((c,z,a.shape));a=o.reshape(H,W,-1)
        f=a.reshape(H*W,-1);out=(f@s.W[3]+s.b[3]).reshape(H,W)
        return (out,(cache,f)) if keep else out
    def backward(s,dout,cache,f,H,W):
        g=[None]*8;d=dout.reshape(-1,1);g[3]=f.T@d;g[7]=d.sum(0);da=d@s.W[3].T
        for k in (2,1,0):
            c,z,shape=cache[k];dz=da*(z>0);g[k]=c.T@dz;g[4+k]=dz.sum(0)
            if k>0:da=s.uncols(dz@s.W[k].T,shape,s.dil[k]).reshape(H*W,-1)
        return g
    def adam(s,g,lr=3e-3):
        s.t+=1;ps=s.W+s.b
        for i,p in enumerate(ps):
            s.m[i]=.9*s.m[i]+.1*g[i];s.v[i]=.999*s.v[i]+.001*g[i]**2
            p-=lr*(s.m[i]/(1-.9**s.t))/(np.sqrt(s.v[i]/(1-.999**s.t))+1e-8)
def train(net,imgs,epochs,seed,crop=64,bs=8,log=True):
    r=np.random.default_rng(seed);n=len(imgs);t0=time.time()
    for ep in range(epochs):
        order=r.permutation(n);tot=0
        for bi in range(0,n,bs):
            gs=None
            for ii in order[bi:bi+bs]:
                x,y=imgs[ii];u,v=r.integers(0,128-crop+1,2);xc=x[u:u+crop,v:v+crop];yc=y[u:u+crop,v:v+crop].astype(float)
                if r.random()<.5:xc,yc=xc[:,::-1],yc[:,::-1]
                if r.random()<.5:xc,yc=xc[::-1],yc[::-1]
                out,(cache,f)=net.forward(np.ascontiguousarray(xc),True);p=expit(out)
                tot+=float(np.mean(np.logaddexp(0,out)-yc*out))
                g=net.backward((p-yc)/(crop*crop),cache,f,crop,crop)
                gs=g if gs is None else [a+b for a,b in zip(gs,g)]
            net.adam([a/len(order[bi:bi+bs]) for a in gs])
        if log and (ep%5==0 or ep==epochs-1):print(f'  ep{ep} loss {tot/n:.4f} t={time.time()-t0:.0f}s',flush=True)
if __name__=='__main__':
    imgs=[phantomA(i,2026+90_000_000) for i in range(20)]
    net=FCN(seed=0);t=time.time();train(net,imgs,2,0);print('2 epochs x 20 imgs',time.time()-t)
    t=time.time();net.forward(phantomA(80)[0]);print('fwd 128x128',time.time()-t)
