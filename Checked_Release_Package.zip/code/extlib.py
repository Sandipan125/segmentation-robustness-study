import sys; sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent))
import numpy as np, pandas as pd
from scipy.ndimage import gaussian_filter, zoom, label
from scipy.special import expit
from scipy.optimize import minimize_scalar, minimize
import reproduce as R
MODELS=['Threshold','Smoothed threshold']
def phantomA(i,seed=2026):
    rng=np.random.default_rng(seed+i)
    yy,xx=np.mgrid[:128,:128]
    cx,cy=rng.uniform(48,80,2);a,b=rng.uniform(16,29,2);ang=rng.uniform(-np.pi,np.pi)
    dx=(xx-cx)*np.cos(ang)+(yy-cy)*np.sin(ang);dy=-(xx-cx)*np.sin(ang)+(yy-cy)*np.cos(ang)
    phi=np.arctan2(dy/b,dx/a);radius=np.sqrt((dx/a)**2+(dy/b)**2)
    boundary=1+rng.uniform(.04,.16)*np.cos(3*phi+rng.uniform(0,2*np.pi))+rng.uniform(.02,.09)*np.sin(5*phi+rng.uniform(0,2*np.pi))
    y=radius<=boundary
    def field(s):
        f=gaussian_filter(rng.normal(size=(128,128)),s);return (f-f.mean())/(f.std()+1e-12)
    background=rng.uniform(.24,.36);contrast=rng.uniform(.12,.34)
    occ=gaussian_filter(y.astype(float),rng.uniform(.6,1.4))
    x=background+contrast*occ
    x+=rng.uniform(.02,.05)*field(18);x+=rng.uniform(.01,.025)*field(2);x+=rng.uniform(.015,.04)*field(5)*occ
    for j in range(int(rng.integers(1,4))):
        qx,qy=rng.uniform(12,116,2);qa,qb=rng.uniform(4,11,2)
        d=((xx-qx)/qa)**2+((yy-qy)/qb)**2<=1
        x+=rng.uniform(.04,.14)*gaussian_filter((d&~y).astype(float),1)
    x+=rng.normal(0,rng.uniform(.025,.075),(128,128))
    return np.clip(x,0,1),y
def phantomB(i,seed=2026):
    """Second, independently specified family: multi-lobed union-of-ellipses targets, linear background
    gradient, intensity ramp inside the target, signal-dependent noise, 2-5 bright or dark distractors."""
    rng=np.random.default_rng(seed+i)
    yy,xx=np.mgrid[:128,:128].astype(float)
    cx,cy=rng.uniform(46,82,2);y=np.zeros((128,128),bool)
    for l in range(int(rng.integers(2,5))):
        ox,oy=rng.uniform(-14,14,2);qa,qb=rng.uniform(9,18,2);an=rng.uniform(0,np.pi)
        dx=(xx-cx-ox)*np.cos(an)+(yy-cy-oy)*np.sin(an);dy=-(xx-cx-ox)*np.sin(an)+(yy-cy-oy)*np.cos(an)
        y|=((dx/qa)**2+(dy/qb)**2)<=1
    def field(s):
        f=gaussian_filter(rng.normal(size=(128,128)),s);return (f-f.mean())/(f.std()+1e-12)
    bg=rng.uniform(.22,.40);g=rng.uniform(.02,.06);th=rng.uniform(0,2*np.pi)
    grad=g*((xx-64)*np.cos(th)+(yy-64)*np.sin(th))/64
    contrast=rng.uniform(.10,.30);tau=rng.uniform(.5,1.6)
    occ=gaussian_filter(y.astype(float),tau)
    ramp=1+rng.uniform(-.3,.3)*((xx-cx)*np.cos(th+1)+(yy-cy)*np.sin(th+1))/20
    x=bg+grad+contrast*occ*ramp
    x+=rng.uniform(.015,.035)*field(3)+rng.uniform(.02,.05)*field(12)
    for j in range(int(rng.integers(2,6))):
        qx,qy=rng.uniform(10,118,2);qa,qb=rng.uniform(3,12,2)
        d=((xx-qx)/qa)**2+((yy-qy)/qb)**2<=1
        sgn=1 if rng.uniform()>.3 else -1
        x+=sgn*rng.uniform(.04,.16)*gaussian_filter((d&~y).astype(float),1.2)
    sd=rng.uniform(.02,.07);x=x+rng.normal(0,1,x.shape)*sd*(.7+.6*np.clip(x,0,1))
    return np.clip(x,0,1),y
def shiftS(x,cond,i,seed=2026):
    if cond=='clean':return x.copy()
    fam,sev=cond.split('_');k=int(sev)-1
    if fam=='noise':
        rng=np.random.default_rng(seed+100000+10*i+int(sev));z=x+rng.normal(0,[.04,.08,.12][k],x.shape)
    elif fam=='blur':z=gaussian_filter(x,[.6,1.2,1.8][k])
    elif fam=='contrast':z=.5+[.8,.6,.4][k]*(x-.5)
    else:
        r=[.75,.5,.25][k];s=zoom(gaussian_filter(x,.5*(1/r-1)),r,order=1,prefilter=False)
        z=zoom(s,tuple(n/m for n,m in zip(x.shape,s.shape)),order=1,prefilter=False)
    return np.clip(z,0,1)
def score(x,m):return x if m=='Threshold' else gaussian_filter(x,.8)
def nll(z,y):return float(np.mean(np.logaddexp(0,z)-y*z))
def fit_config(pf,seed):
    cfg={}
    dev=[pf(i,seed) for i in range(40)];cal=[pf(i,seed) for i in range(40,80)]
    grid=np.linspace(.30,.70,41)
    for m in MODELS:
        S=[(score(x,m),y) for x,y in dev]
        ds=[np.mean([R.dice(s>=t,y) for s,y in S]) for t in grid];th=float(grid[int(np.argmax(ds))])
        Z=np.stack([(score(x,m)-th)/.08 for x,y in cal]);L=np.stack([y for x,y in cal])
        f=minimize_scalar(lambda lt:nll(Z/np.exp(lt),L),bounds=(np.log(.05),np.log(10)),method='bounded')
        pl=minimize(lambda p:nll(p[0]*Z+p[1],L),[1.,0.],method='L-BFGS-B')
        cfg[m]={'threshold':th,'temperature':float(np.exp(f.x)),'platt_a':float(pl.x[0]),'platt_b':float(pl.x[1])}
    return cfg
def prob_row(S,y,c):
    z=(S-c['threshold'])/.08
    pr=expit(z);pt=expit(z/c['temperature']);pp=expit(c['platt_a']*z+c['platt_b'])
    return {'dice':R.dice(z>=0,y),
      'brier_raw':float(2*np.mean((pr-y)**2)),'brier_temp':float(2*np.mean((pt-y)**2)),'brier_platt':float(2*np.mean((pp-y)**2)),
      'nll_raw':nll(z,y),'nll_temp':nll(z/c['temperature'],y),'nll_platt':nll(c['platt_a']*z+c['platt_b'],y)}
