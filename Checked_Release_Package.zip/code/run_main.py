from extlib import *
import time
CONDS=R.CONDITIONS;cfg=fit_config(phantomA,2026)
CS=[.8,.6,.4]
def largest_cc(p):
    l,n=label(p)
    if n<=1:return p
    c=np.bincount(l.ravel());c[0]=0;return l==c.argmax()
rows=[];sweep=[];grid=np.linspace(.30,.70,41)
t0=time.time()
for i in range(80,160):
    x,y=phantomA(i)
    for cond in CONDS:
        xs=shiftS(x,cond,i)
        for m,o in zip(MODELS,MODELS[::-1]):
            c=cfg[m];S=score(xs,m);pred=S>=c['threshold']
            r={'model':m,'case':i,'condition':cond,**prob_row(S,y,c)}
            r['hd95']=R.hd95(pred,y);cc=largest_cc(pred);r['dice_cc']=R.dice(cc,y);r['hd95_cc']=R.hd95(cc,y)
            r['dice_swap']=R.dice(S>=cfg[o]['threshold'],y)          # other method's threshold
            r['dice_common']=R.dice(S>=.43,y)                          # common threshold 0.43
            if cond.startswith('contrast'):
                cs=CS[int(cond[-1])-1];r['dice_aware']=R.dice(S>=.5+cs*(c['threshold']-.5),y)
            else:r['dice_aware']=np.nan
            rows.append(r)
            if cond in('clean','contrast_3'):
                for t in grid:sweep.append({'model':m,'case':i,'condition':cond,'theta':t,'dice':R.dice(S>=t,y)})
df=pd.DataFrame(rows);df.to_csv('ext_main_case.csv',index=False)
sw=pd.DataFrame(sweep).groupby(['model','condition','theta']).dice.mean().reset_index();sw.to_csv('ext_sweep.csv',index=False)
print(time.time()-t0,cfg)
def ci(v):return R.ci(v)
out=[]
for (m,cond),d in df.groupby(['model','condition']):
    r={'model':m,'condition':cond}
    for k in ['dice','hd95','dice_cc','hd95_cc','dice_swap','dice_common','dice_aware','brier_raw','brier_temp','brier_platt','nll_raw','nll_temp','nll_platt']:
        r[k]=d[k].mean()
    out.append(r)
o=pd.DataFrame(out).set_index(['model','condition']);o.to_csv('ext_main_summary.csv')
pd.set_option('display.width',250)
sel=['clean','noise_3','blur_3','contrast_1','contrast_2','contrast_3','resolution_3']
print(o.loc[(slice(None),sel),:].round(3).to_string())
print(sw[sw.condition=='contrast_3'].sort_values('dice').groupby('model').tail(1))
print(sw[sw.condition=='clean'].sort_values('dice').groupby('model').tail(1))
