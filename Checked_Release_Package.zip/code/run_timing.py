import sys;sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent))
from cnn import *
import time,platform
cal=[phantomA(i,2026) for i in range(40,80)];m='Smoothed threshold';cfg=fit_config(phantomA,2026)[m]
Z=np.stack([(score(x,m)-cfg['threshold'])/.08 for x,y in cal]);L=np.stack([y for x,y in cal])
def t_temp():
    f=minimize_scalar(lambda lt:nll(Z/np.exp(lt),L),bounds=(np.log(.05),np.log(10)),method='bounded');return f
def t_platt():
    return minimize(lambda p:nll(p[0]*Z+p[1],L),[1.,0.],method='L-BFGS-B')
res={}
for name,fn in [('temperature_fit',t_temp),('platt_fit',t_platt)]:
    fn();ts=[]
    for _ in range(15):
        t=time.perf_counter();r=fn();ts.append(time.perf_counter()-t)
    nfev=getattr(r,'nfev',None);res[name]=(np.mean(ts),np.std(ts),nfev)
z1=Z[0];ti=cfg['temperature']
def inf_temp():return expit(z1/ti)
def inf_platt():return expit(1.2*z1-.9)
for name,fn in [('temperature_apply',inf_temp),('platt_apply',inf_platt)]:
    ts=[]
    for _ in range(30):
        t=time.perf_counter()
        for _ in range(100):fn()
        ts.append((time.perf_counter()-t)/100)
    res[name]=(np.mean(ts),np.std(ts),None)
net=FCN(seed=0);x=cal[0][0];ts=[]
for _ in range(15):
    t=time.perf_counter();net.forward(x);ts.append(time.perf_counter()-t)
res['cnn_forward']=(np.mean(ts),np.std(ts),None)
ts=[]
for _ in range(50):
    t=time.perf_counter();gaussian_filter(x,.8);ts.append(time.perf_counter()-t)
res['gaussian_filter']=(np.mean(ts),np.std(ts),None)
out=pd.DataFrame([{'operation':k,'mean_ms':v[0]*1e3,'sd_ms':v[1]*1e3,'function_evals':v[2]} for k,v in res.items()])
out['n_pixels']=Z.size;out['platform']=platform.platform();out.to_csv('ext_timing.csv',index=False);print(out.round(3).to_string())
