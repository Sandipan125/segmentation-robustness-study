"""Controlled heterogeneous phantom simulation. All reported metrics are computed."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter, zoom, binary_erosion, distance_transform_edt
from scipy.special import expit, logit
from scipy.optimize import minimize_scalar
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
SEED=2026
CONDITIONS=['clean']+[f'{f}_{i}' for f in ['noise','blur','contrast','resolution'] for i in [1,2,3]]
def phantom(i):
    rng=np.random.default_rng(SEED+i)
    yy,xx=np.mgrid[:128,:128]
    cx,cy=rng.uniform(48,80,2);a,b=rng.uniform(16,29,2);ang=rng.uniform(-np.pi,np.pi)
    dx=(xx-cx)*np.cos(ang)+(yy-cy)*np.sin(ang)
    dy=-(xx-cx)*np.sin(ang)+(yy-cy)*np.cos(ang)
    phi=np.arctan2(dy/b,dx/a)
    radius=np.sqrt((dx/a)**2+(dy/b)**2)
    boundary=1+rng.uniform(.04,.16)*np.cos(3*phi+rng.uniform(0,2*np.pi))+rng.uniform(.02,.09)*np.sin(5*phi+rng.uniform(0,2*np.pi))
    y=radius<=boundary
    def field(scale):
        f=gaussian_filter(rng.normal(size=(128,128)),scale)
        return (f-f.mean())/(f.std()+1e-12)
    background=rng.uniform(.24,.36);contrast=rng.uniform(.12,.34)
    occupancy=gaussian_filter(y.astype(float),rng.uniform(.6,1.4))
    x=background+contrast*occupancy
    # Smooth bias, correlated texture, local heterogeneity and independent noise.
    x+=rng.uniform(.02,.05)*field(18)
    x+=rng.uniform(.01,.025)*field(2)
    x+=rng.uniform(.015,.04)*field(5)*occupancy
    # Nontarget bright structures have distinct labels but overlapping intensities.
    for j in range(int(rng.integers(1,4))):
        qx,qy=rng.uniform(12,116,2);qa,qb=rng.uniform(4,11,2)
        distractor=((xx-qx)/qa)**2+((yy-qy)/qb)**2<=1
        x+=rng.uniform(.04,.14)*gaussian_filter((distractor & ~y).astype(float),1)
    x+=rng.normal(0,rng.uniform(.025,.075),(128,128))
    return np.clip(x,0,1),y

def shift(x,cond,i):
    if cond=='clean':return x.copy()
    family,severity=cond.split('_');k=int(severity)-1
    if family=='noise':
        rng=np.random.default_rng(SEED+100000+10*i+int(severity));z=x+rng.normal(0,[.04,.08,.12][k],x.shape)
    elif family=='blur':z=gaussian_filter(x,[.6,1.2,1.8][k])
    elif family=='contrast':z=.5+[.8,.6,.4][k]*(x-.5)
    elif family=='resolution':
        r=[.75,.5,.25][k];small=zoom(gaussian_filter(x,.5*(1/r-1)),r,order=1,prefilter=False)
        z=zoom(small,tuple(n/m for n,m in zip(x.shape,small.shape)),order=1,prefilter=False)
    return np.clip(z,0,1)

def score_image(x,model):return x if model=='Threshold' else gaussian_filter(x,.8)
def dice(p,y):return 2*np.count_nonzero(p&y)/(p.sum()+y.sum())
def hd95(p,y):
    if not p.any() or not y.any():return np.nan
    a=p^binary_erosion(p);b=y^binary_erosion(y)
    return max(np.percentile(distance_transform_edt(~a)[b],95),np.percentile(distance_transform_edt(~b)[a],95))
def prob_metrics(p,y):
    p=np.asarray(p);conf=np.maximum(p,1-p);ok=(p>=.5)==y
    bins=np.minimum((conf*15).astype(int),14);ece=0
    for b in range(15):
        ix=bins==b
        if ix.any():ece+=ix.mean()*abs(ok[ix].mean()-conf[ix].mean())
    return float(ece),float(2*np.mean((p-y)**2))
def ci(x):
    x=np.asarray(x);rng=np.random.default_rng(SEED)
    means=x[rng.integers(0,len(x),(2000,len(x)))].mean(1)
    return np.quantile(means,[.025,.975])
def main():
    configs={};models=['Threshold','Smoothed threshold']
    for model in models:
        grid=np.linspace(.30,.70,41);ds=[]
        development=[(score_image(phantom(i)[0],model),phantom(i)[1]) for i in range(40)]
        for threshold in grid:
            ds.append(np.mean([dice(x>=threshold,y) for x,y in development]))
        threshold=float(grid[np.argmax(ds)])
        logits=[];labels=[]
        for i in range(40,80):
            x,y=phantom(i);logits.append((score_image(x,model)-threshold)/.08);labels.append(y)
        logits=np.stack(logits);labels=np.stack(labels)
        def nll(logt):
            z=logits/np.exp(logt)
            return float(np.mean(np.logaddexp(0,z)-labels*z))
        fit=minimize_scalar(nll,bounds=(np.log(.05),np.log(10)),method='bounded')
        assert fit.success
        configs[model]={'threshold':threshold,'temperature':float(np.exp(fit.x)),'calibration_nll_raw':nll(0),'calibration_nll_scaled':float(fit.fun)}
    rows=[]
    for model in models:
        cfg=configs[model]
        for i in range(80,160):
            x,y=phantom(i)
            for cond in CONDITIONS:
                z=(score_image(shift(x,cond,i),model)-cfg['threshold'])/.08
                p=expit(z);pc=expit(z/cfg['temperature']);pred=p>=.5
                er,br=prob_metrics(p,y);ec,bc=prob_metrics(pc,y)
                rows.append({'model':model,'case':i,'condition':cond,'dice':dice(pred,y),'hd95_pixels':hd95(pred,y),'ece_raw':er,'ece_scaled':ec,'brier_raw':br,'brier_scaled':bc})
    df=pd.DataFrame(rows);df.to_csv(ROOT/'synthetic_case_metrics.csv',index=False)
    assert len(df)==2080 and df.hd95_pixels.notna().all()
    summaries=[]
    for (model,cond),d in df.groupby(['model','condition']):
        row={'model':model,'condition':cond}
        for metric in ['dice','hd95_pixels','ece_raw','ece_scaled','brier_raw','brier_scaled']:
            row[metric]=d[metric].mean()
            row[metric+'_ci_low'],row[metric+'_ci_high']=ci(d[metric])
        row['dice_ci_low'],row['dice_ci_high']=ci(d.dice)
        summaries.append(row)
    sm=pd.DataFrame(summaries);sm.to_csv(ROOT/'synthetic_summary.csv',index=False)
    pairs=[]
    for cond in CONDITIONS:
        a=df[(df.model==models[0])&(df.condition==cond)].set_index('case');b=df[(df.model==models[1])&(df.condition==cond)].set_index('case').loc[a.index]
        v=b.dice-a.dice;lo,hi=ci(v)
        pairs.append({'condition':cond,'mean_dice_difference':v.mean(),'ci_low':lo,'ci_high':hi})
    pd.DataFrame(pairs).to_csv(ROOT/'synthetic_paired_comparisons.csv',index=False)
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    colors=['#3265a8','#c25432']
    for metric,ylabel,out in [('dice','Dice coefficient','robustness'),('brier_scaled','Temperature-scaled Brier score','calibration')]:
        fig,axs=plt.subplots(1,4,figsize=(11,2.8),sharey=True)
        for ax,family in zip(axs,['noise','blur','contrast','resolution']):
            for model,color in zip(models,colors):
                d=sm[sm.model==model].set_index('condition').loc[['clean']+[f'{family}_{i}' for i in [1,2,3]]]
                ax.plot(range(4),d[metric],'o-',label=model,color=color,markersize=4)
                ax.fill_between(range(4),d[metric+'_ci_low'].to_numpy(),d[metric+'_ci_high'].to_numpy(),alpha=.18,color=color)
            ax.set(xlabel='Severity level',title=family.capitalize(),xticks=range(4))
            ax.grid(alpha=.18)
        axs[0].set_ylabel(ylabel);axs[-1].legend(fontsize=7)
        fig.tight_layout();fig.savefig(ROOT/(out+'.png'),dpi=300);fig.savefig(ROOT/(out+'.pdf'));plt.close(fig)
    fig,axs=plt.subplots(2,5,figsize=(11,4.5))
    for row,i in enumerate([80,81]):
        x,y=phantom(i)
        for ax,cond in zip(axs[row],['clean','noise_3','blur_3','contrast_3','resolution_3']):
            shifted=shift(x,cond,i)
            ax.imshow(shifted,cmap='gray',vmin=0,vmax=1)
            ax.contour(y,levels=[.5],colors=['#5dff72'],linewidths=.6)
            pred=score_image(shifted,models[1])>=configs[models[1]]['threshold']
            ax.contour(pred,levels=[.5],colors=['#ff6868'],linewidths=.45)
            ax.set_title(f'Case {i}: '+cond.replace('_',' '),fontsize=8);ax.axis('off')
    fig.tight_layout();fig.savefig(ROOT/'examples.png',dpi=220);fig.savefig(ROOT/'examples.pdf');plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(7,3))
    for ax,cond in zip(axs,['clean','noise_3']):
        d=df[df.condition==cond].pivot(index='case',columns='model',values='dice')
        ax.scatter(d[models[0]],d[models[1]],s=14,alpha=.65,color=colors[0])
        ax.plot([0,1],[0,1],'--',color='gray',linewidth=1)
        ax.set(xlim=(0,1),ylim=(0,1),xlabel='Threshold Dice',ylabel='Smoothed threshold Dice',title=cond.replace('_',' '))
        ax.grid(alpha=.18)
    fig.tight_layout();fig.savefig(ROOT/'case_comparison.png',dpi=300);plt.close(fig)
    atomic={'status':'COMPUTED_SYNTHETIC_PHANTOM_EXPERIMENT','seed':SEED,'development_ids':list(range(40)),'calibration_ids':list(range(40,80)),'test_ids':list(range(80,160)),'models':configs,'no_patient_data':True,'no_neural_network_training':True,'bootstrap_replicates':2000,'experiment_revision':'heterogeneous-v1','threshold_grid':[.30,.70,41]}
    (ROOT/'simulation_metadata.json').write_text(json.dumps(atomic,indent=2))
    print(sm[sm.condition.isin(['clean','noise_3','blur_3','contrast_3','resolution_3'])].to_string(index=False))
if __name__=='__main__':main()
