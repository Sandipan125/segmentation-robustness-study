from extlib import *
import time
C5=['clean','noise_3','blur_3','contrast_3','resolution_3']
cfgA0=fit_config(phantomA,2026)   # main-experiment fit, used for cross-generator transfer
rows=[];t0=time.time()
def run(fam,pf,r,seed,cfg,fit_tag):
    for i in range(80,160):
        x,y=pf(i,seed)
        for cond in C5:
            xs=shiftS(x,cond,i,seed)
            Ss={m:score(xs,m) for m in MODELS}
            for m in MODELS:
                rows.append({'family':fam,'rep':r,'fit':fit_tag,'model':m,'case':i,'condition':cond,'theta':cfg[m]['threshold'],'temp':cfg[m]['temperature'],**prob_row(Ss[m],y,cfg[m])})
for r in range(1,21):
    sA=2026+1_000_000*r;cA=fit_config(phantomA,sA);run('A',phantomA,r,sA,cA,'own')
    sB=2026+50_000_000+1_000_000*r;cB=fit_config(phantomB,sB)
    run('B',phantomB,r,sB,cB,'own');run('B',phantomB,r,sB,cfgA0,'fromA')
    print(r,round(time.time()-t0),cA['Threshold']['threshold'],cA['Smoothed threshold']['threshold'],cB['Threshold']['threshold'],cB['Smoothed threshold']['threshold'],flush=True)
pd.DataFrame(rows).to_csv('ext_rep_case.csv',index=False)
