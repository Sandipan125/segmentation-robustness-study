import pandas as pd,numpy as np
d=pd.concat([pd.read_csv(f'cnn_seed{s}.csv') for s in (1,2,3)]);d.to_csv('ext_cnn_case.csv',index=False)
g=d.groupby(['seed','condition']).mean(numeric_only=True).reset_index()
rows=[]
for c in ['clean','noise_3','blur_3','contrast_3','resolution_3']:
    x=g[g.condition==c];r={'condition':c}
    for k in ['dice','hd95','brier_raw','brier_temp','brier_platt','nll_raw','nll_temp','nll_platt']:
        r[k]=x[k].mean();r[k+'_sd']=x[k].std();r[k+'_min']=x[k].min();r[k+'_max']=x[k].max()
    r['tempBrierWorse']=int((x.brier_temp>x.brier_raw).sum());r['plattBrierWorse']=int((x.brier_platt>x.brier_raw).sum())
    r['tempNLLWorse']=int((x.nll_temp>x.nll_raw).sum());r['plattNLLWorse']=int((x.nll_platt>x.nll_raw).sum())
    rows.append(r)
o=pd.DataFrame(rows);o.to_csv('ext_cnn_summary.csv',index=False)
pd.set_option('display.width',250)
print(o[['condition','dice','dice_sd','hd95','hd95_sd','brier_raw','brier_temp','brier_platt','nll_raw','nll_temp','nll_platt','tempBrierWorse','plattBrierWorse','tempNLLWorse','plattNLLWorse']].round(3).to_string())
print(pd.concat([pd.read_csv(f'cnn_cfg{s}.csv') for s in (1,2,3)]).round(3))
# all 13 conditions: temp/platt worse counts
a=g.copy();print('temp brier worse over all cond x seeds',int((a.brier_temp>a.brier_raw+1e-12).sum()),'of',len(a),' platt',int((a.brier_platt>a.brier_raw).sum()),' platt nll',int((a.nll_platt>a.nll_raw).sum()))
