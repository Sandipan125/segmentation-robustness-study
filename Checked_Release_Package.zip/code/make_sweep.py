import pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Liberation Serif','DejaVu Serif'],'font.size':7,'axes.linewidth':.6,'axes.spines.top':False,'axes.spines.right':False})
sw=pd.read_csv('ext_sweep.csv');cols={'Threshold':'#1f4e9c','Smoothed threshold':'#b8412a'};lab={'Threshold':'T','Smoothed threshold':'ST'}
fig,ax=plt.subplots(figsize=(3.45,1.4))
for m in cols:
    for cond,ls in [('clean','--'),('contrast_3','-')]:
        d=sw[(sw.model==m)&(sw.condition==cond)];ax.plot(d.theta,d.dice,ls,color=cols[m],lw=1,label=f"{lab[m]}, {cond.replace('_3',' 3')}")
for th,c in [(.44,cols['Threshold']),(.42,cols['Smoothed threshold'])]:ax.axvline(th,color=c,lw=.6,ls=':')
ax.set(xlabel=r'Threshold $\theta$ applied to the (transformed) score',ylabel='Mean Dice',xlim=(.30,.70),ylim=(0,.9));ax.grid(alpha=.25,lw=.4)
ax.legend(fontsize=6,frameon=False,loc='upper right',ncol=1)
fig.tight_layout(pad=.3);fig.savefig('sweep.pdf')
